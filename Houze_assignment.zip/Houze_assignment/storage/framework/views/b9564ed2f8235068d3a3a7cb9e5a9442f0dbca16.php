<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
            <?php if($id == 2): ?>
                <div class="card-header">Films</div>

                <div class="card-body">
                <table id= "save_data"  border="1" align="center" autosize="1.6" style="text-align:center;border-collapse: collapse; width:98%; margin-top:10px; ">
                <tr>
                <th>Sr.No.</th>
                <th>Film Name</th>        
                </tr>
                <?php if(count($data)>0): ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr><td><?php echo e($key+1); ?></td>
                <td><?php echo e($film->m_name); ?>

                </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <tr>
                <td>No records found
                </td>
                <td>No records found
                </td>
                </tr>
                <?php endif; ?>
                </table>
                </div>  
        <?php elseif($id==3): ?>
                <div class="card-header">People/Character</div>

                <div class="card-body">
                <table id= "save_data"  border="1" align="center" autosize="1.6" style="text-align:center;border-collapse: collapse; width:98%; margin-top:10px; ">
                <tr>
                <th>Sr.No.</th>
                <th>People</th> 
                <th>Character</th>       
                </tr>
                <?php if(count($data)>0): ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$people): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr><td><?php echo e($key+1); ?></td>
                <td><?php echo e($people->m_people); ?>

                </td>
                <td><?php echo e($people->m_character); ?>

                </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <tr>
                <td>No records found
                </td>
                <td>No records found
                </td>
                <td>No records found
                </td>
                </tr>
                <?php endif; ?>
                </table>
                </div>  
                <?php endif; ?>             
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<script>


    
</script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Houze_assignment\resources\views/master.blade.php ENDPATH**/ ?>