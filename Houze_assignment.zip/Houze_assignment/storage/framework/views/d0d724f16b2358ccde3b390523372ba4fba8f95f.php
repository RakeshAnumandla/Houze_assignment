<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Upload Excel</div>

                <div class="card-body">
                <div class="row">
		
				<div class="col-md-12">
                <form id="masteruploadexcelfile">
				
				<div class="col-md-4">				
					<input name="uploadexcel" required id="uploadexcel" type="file">
					<label> (Upload xls,xlsx extension files only.)</label>
				</div>
				<div class="col-md-2" >
					<button type="submit"  class="btn btn-info btn-lg">Upload Excel</button>
				</div>	
				</form>
			</div>
		
	            </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
$("#masteruploadexcelfile").validate({
    rules: {
        hpexcel_file: {
            required: true,
        },

    },
    errorPlacement: function(error, element) {
        error.insertAfter(element);
    },
    submitHandler: function(form, event) {
        var a = new FormData($("#masteruploadexcelfile")[0]);
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            url: "/masteruploadexcelfile",
            type: "POST",
            data: a,
            processData: false,
            contentType: false,
            success: function(response) {
                console.log(response);
                if (response.status == 200) {
                    success_alert(response.message);
                    $("#masteruploadexcelfile")[0].reset();
                    //window.setTimeout(function() { location.reload(); }, 1000)
                } else {
                    error_alert(response.message)
                }
            },
            error: function(error) {
                console.log(error);

            }
        });
    }

});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\supplier\resources\views/home.blade.php ENDPATH**/ ?>