<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Master</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="btn-group">
                        <button type="button" class="btn btn-primary dropdown-toggle" aria-labelledby="dropdownMenuDivider"data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                             Product/Part Details<span class="caret"></span>
                        </button>
                        <ul class="dropdown-menu">
                            <li role="separator" class="divider"><a role="menuitem" href="#">Part 1</a></li>
                            
                            <li role="separator" class="divider"><a role="menuitem" href="#">Part 2</a></li>
                           
                            <li role="separator" class="divider"><a role="menuitem" href="#">Part 3</a></li>                        
                        </ul>
                    </div>&nbsp;
                    <div class="btn-group">
                        <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Inspection Record <span class="caret"></span>
                        </button>
                            <ul class="dropdown-menu">
                                <li><a href="inspection">Inspection Part 1</a></li>
                                <li><a href="#">Inspection Part 2</a></li>
                                <li><a href="#">Inspection Part 3</a></li>                                
                            </ul>
                    </div>&nbsp;
                    <div class="btn-group">
                        <a class="btn btn-info" href="graph">
                            Graphs <span class="caret"></span>
                        </a>
                        
                    </div>
                </div>                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<script>


    
</script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\supplier\resources\views/master.blade.php ENDPATH**/ ?>