<?php $__env->startSection('content'); ?>
<div class="container">

    <?php if(\Session::has('status')): ?>
    <div class="alert alert-success">
        <?php echo \Session::get('status'); ?> 
    </div>
<?php endif; ?>
<?php if(\Session::has('error')): ?>
    <div class="alert alert-danger">
        <?php echo \Session::get('error'); ?> 
    </div>
<?php endif; ?>

    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">HOME</div>

                <div class="card-body">
                <div class="row">
		
				<div class="col-md-12">
                <form id="masteruploadexcelfile">
				
				<section class="col-md-4">	
                    <label class="input">First Name <sup class="asterisk error">*</sup> </label>			
					<input name="m_first_name" class="form-control" id="m_first_name" type="text">				
				</section>
                <section class="col-md-4">	
                    <label class="input">Last Name <sup class="asterisk">*</sup> </label>			
					<input name="m_last_name" class="form-control" id="m_last_name" type="text">				
				</section>
                <br>
                <section class="col-md-4">	
                <button type="button"  class="btn btn-success btn-lg" onclick="Action(1)">Save Data</button>				           				
				</section>
                
                <table id= "save_data"  border="1" align="center" autosize="1.6" style="text-align:center;border-collapse: collapse; width:98%; margin-top:10px; ">
                
                
                </table>
                <br>
                <footer>
                
					
					<button type="button"  class="btn btn-info btn-lg" onclick="Action(2)">Get Films</button>
                    <button type="button"  class="btn btn-primary btn-lg" onclick="Action(3)">Get Peoples</button>
				
                <footer>
					
				</form>
			</div>
		
	            </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="<?php echo e(URL::asset('assets/js/jquery-1.11.1.min.js')); ?>"></script>
<script>
$(document).ready(function () {
    getSaveData();
});
function Action (id){
    if(id==1){
        if($.trim($('#m_first_name').val()) == ''){
            alert('Please enter First Name');
            return false;
        }else if($.trim($('#m_last_name').val()) == ''){
            alert('Please enter Last Name');
            return false;
        }
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                url: "/action",
                type: "post",   
                data:{'m_first_name': $.trim($('#m_first_name').val()),'m_last_name':$.trim($('#m_last_name').val()),'id':id} ,       
                success: function(response) {
                    console.log(response);
                    if(response.status == 200){
                        alert(response.message);
                        getSaveData();
                    }else{
                        alert('Something went wrong')
                    }
                    
                },
                error: function(error) {
                    console.log(error);

                }
        });
    }else if(id==2) { 
       window.open('getfilms/'+id) ;
    }else if(id==3){
        window.open('getpeoples/'+id); 
    }


   
}
function getSaveData(){
    $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            url: "/getSaveData",
            type: "GET",           
            success: function(response) {
                console.log(response);
                var html='<tr>';
                html+= '<th>Sr.No.</th>';
                html+= '<th>First Name</th>';
                html+='<th>Last Name</th>';
                html+= '</tr>';
                
                if(response.status == 200){
                    if(response.message.length>0){
                            for(var i=0;i<response.message.length;i++){
                                // console.log(response.message[i].m_first_name)
                                // console.log(response.message[i].m_last_name)
                                html+='<tr>';
                                html+='<td>'+ parseInt(i+1) +'</td>';         
                                html+='<td>'+ response.message[i].m_first_name +'</td>';
                                html+='<td>'+ response.message[i].m_last_name +'</td>';                                                               
                                html+='<tr>';
                            }
                    }else{
                        html+='<tr>';
                        html+='<td>No records found</td>'; 
                        html+='<td>No records found</td>'; 
                        html+='<td>No records found</td>';                                
                        html+='<tr>';
                    }
                   
                }else{
                        html+='<tr>';
                        html+='<td>No records found</td>'; 
                        html+='<td>No records found</td>'; 
                        html+='<td>No records found</td>';                                
                        html+='<tr>';
                }
                $('#save_data').html(html);
            },
            error: function(error) {
                console.log(error);

            }
    });
}

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Houze_assignment\resources\views/home.blade.php ENDPATH**/ ?>