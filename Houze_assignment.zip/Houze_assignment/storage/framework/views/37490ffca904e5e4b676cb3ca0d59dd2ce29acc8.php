<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Supplier</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="btn-group">
                        <button type="button" class="btn btn-warning dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                             Supplier Details<span class="caret"></span>
                        </button>
                        <ul class="dropdown-menu">
                            <li><a href="#">Supplier 1</a></li>
                            <li><a href="#">Supplier 2</a></li>
                            <li><a href="#">Supplier 3</a></li>                        
                        </ul>
                    </div>&nbsp;
                    <div class="btn-group">
                        <button type="button" class="btn btn-danger" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Compares  Supplies <span class="caret"></span>
                        </button>
                            
                    </div>&nbsp;
                   
                </div>                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\supplier\resources\views/supplier.blade.php ENDPATH**/ ?>