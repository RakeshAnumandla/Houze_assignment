@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
           
                <div class="card-header">Films</div>

                <div class="card-body">
                <table id= "save_data"  border="1" align="center" autosize="1.6" style="text-align:center;border-collapse: collapse; width:98%; margin-top:10px; ">
                <tr>
                <th>Sr.No.</th>
                <th>Film Name</th>        
                </tr>
                @if(count($Films)>0)
                @foreach($Films as $key=>$film)
                <tr><td>{{$key+1}}</td>
                <td><a href="JavaScript:void(0);"onclick="getpeoplefilms('{{$film}}',3)">{{$film}}</a>
                
                </td>
                </tr>
                @endforeach
                @else
                <tr>
                <td>No records found
                </td>
                <td>No records found
                </td>
                </tr>
                @endif
                </table>
                </div>  
       
                <div class="card-header">People/Character</div>

                <div class="card-body">
                <table id= "save_data"  border="1" align="center" autosize="1.6" style="text-align:center;border-collapse: collapse; width:98%; margin-top:10px; ">
                <tr>
                <th>Sr.No.</th>
                <th>People</th>                    
                </tr>
                @if(count($PeopleCharacters)>0)
                @foreach($PeopleCharacters as $key=>$people)
                <tr><td>{{$key+1}}</td>
                <td ><a href="JavaScript:void(0);"onclick="getpeoplefilms('{{$people}}',2)">{{$people}}</a>
                
                </td>
                
                </tr>
                @endforeach
                @else
                <tr>
                <td>No records found
                </td>
                <td>No records found
                </td>
                <td>No records found
                </td>
                </tr>
                @endif
                </table>
                </div>  
                        
            </div>
        </div>
    </div>
</div>
<div id="myModal_films" class="modal fade" role="dialog" data-backdrop="static">
		<div class="modal-dialog modal-lg" style="overflow-y: initial !important">

			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					Films
					
				</div>
				<div class="modal-body">
					<!--<button type="button" class="btn btn-info right btn-xs" id="addorderrowbtn" onclick="addRowtogrid()">Add</button>-->
					<table id= "save_data_films"  border="1" align="center" autosize="1.6" style="text-align:center;border-collapse: collapse; width:98%; margin-top:10px; ">
                    </table>
				</div>
				<div class="modal-footer">					
					<button type="button" class="btn btn-danger" data-dismiss="modal">Back</button>
				</div>
			</div>

		</div>
</div>

<div id="myModal_people" class="modal fade" role="dialog" data-backdrop="static">
		<div class="modal-dialog modal-lg" style="overflow-y: initial !important">

			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					Characters					
				</div>
				<div class="modal-body">
					<!--<button type="button" class="btn btn-info right btn-xs" id="addorderrowbtn" onclick="addRowtogrid()">Add</button>-->
					<table id= "save_data_people"  border="1" align="center" autosize="1.6" style="text-align:center;border-collapse: collapse; width:98%; margin-top:10px; ">
                    </table>
				</div>
				<div class="modal-footer">					
					<button type="button" class="btn btn-danger" data-dismiss="modal">Back</button>
				</div>
			</div>

		</div>
</div>
<script src="{{URL::asset('assets/js/jquery-1.11.1.min.js')}}"></script>
<script>

function getpeoplefilms(name,id){
   
    
    $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            url: "/getpeoplefilms",
            type: "post", 
            dataType:'json' ,
            data:{'name':name,'id': id},         
            success: function(response) {
                console.log(response);                              
                var html='<tr>';
                html+= '<th>Sr.No.</th>';
                html+= '<th> Name</th>';               
                html+= '</tr>';
                
                if(response.status == 200){
                    if(response.message.length>0){
                            for(var i=0;i<response.message.length;i++){
                                // console.log(response.message[i].m_first_name)
                                // console.log(response.message[i].m_last_name)
                                html+='<tr>';
                                html+='<td>'+ parseInt(i+1) +'</td>';         
                                html+='<td>'+ response.message[i] +'</td>';                                                                                             
                                html+='<tr>';
                            }
                    }else{
                        html+='<tr>';
                        html+='<td>No records found</td>'; 
                        html+='<td>No records found</td>';                                                       
                        html+='<tr>';
                    }
                   
                }else{
                        html+='<tr>';
                        html+='<td>No records found</td>'; 
                        html+='<td>No records found</td>';                                                    
                        html+='<tr>';
                }
                    if(id == 2){
                        $('#save_data_films').html(html);
                        $('#myModal_films').modal('show')
                    }else{
                        $('#save_data_people').html(html);
                        $('#myModal_people').modal('show')
                    }
                
            },
            error: function(error) {
                
                console.log(error);

            }
        });
}

    
</script>
@endsection