@extends('layouts.app')

@section('content')
<style>

@import url(https://fonts.googleapis.com/css?family=Roboto:300,400);
body {
  height: 100%;
  padding: 0px;
  margin: 0px;
  background: #333;
  font-family: 'Roboto', sans-serif !important;
  font-size: 1em;
}
h1{
  font-family: 'Roboto', sans-serif;
  font-size: 30px;
  color: #999;
  font-weight: 300;
  margin-bottom: 55px;
  margin-top: 45px;
  text-transform: uppercase;
}
h1 small{
  display: block;
  font-size: 18px;
  text-transform: none;
  letter-spacing: 1.5px;
  margin-top: 12px;
}
.row{
  max-width: 950px;
  margin: 0 auto;
}
.btn{
  white-space: normal;
}
.button-wrap {
  position: relative;
  text-align: center;
  .btn {
    font-family: 'Roboto', sans-serif;
    box-shadow: 0 0 15px 5px rgba(0, 0, 0, 0.5);
    border-radius: 0px;
    border-color: #222;
    cursor: pointer;
    text-transform: uppercase;
    font-size: 1.1em;
    font-weight: 400;
    letter-spacing: 1px;
    small {
      font-size: 0.8rem;
      letter-spacing: normal;
      text-transform: none;
    }
  }
}


/** SPINNER CREATION **/

.loader {
  position: relative;
  text-align: center;
  margin: 15px auto 35px auto;
  z-index: 9999;
  display: block;
  width: 80px;
  height: 80px;
  border: 10px solid rgba(0, 0, 0, .3);
  border-radius: 50%;
  border-top-color: #000;
  animation: spin 1s ease-in-out infinite;
  -webkit-animation: spin 1s ease-in-out infinite;
}

@keyframes spin {
  to {
    -webkit-transform: rotate(360deg);
  }
}

@-webkit-keyframes spin {
  to {
    -webkit-transform: rotate(360deg);
  }
}


/** MODAL STYLING **/

.modal-content {
  border-radius: 0px;
  box-shadow: 0 0 20px 8px rgba(0, 0, 0, 0.7);
}

.modal-backdrop.show {
  opacity: 0.75;
}

.loader-txt {
  p {
    font-size: 13px;
    color: #666;
    small {
      font-size: 11.5px;
      color: #999;
    }
  }
}

#output {
  padding: 25px 15px;
  background: #222;
  border: 1px solid #222;
  max-width: 350px;
  margin: 35px auto;
  font-family: 'Roboto', sans-serif !important;
  p.subtle {
    color: #555;
    font-style: italic;
    font-family: 'Roboto', sans-serif !important;
  }
  h4 {
    font-weight: 300 !important;
    font-size: 1.1em;
    font-family: 'Roboto', sans-serif !important;
  }
  p {
    font-family: 'Roboto', sans-serif !important;
    font-size: 0.9em;
    b {
      text-transform: uppercase;
      text-decoration: underline;
    }
  }
}
</style>
<div class="container">

    @if (\Session::has('status'))
    <div class="alert alert-success">
        {!! \Session::get('status') !!} 
    </div>
@endif
@if (\Session::has('error'))
    <div class="alert alert-danger">
        {!! \Session::get('error') !!} 
    </div>
@endif

    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">HOME</div>

                <div class="card-body">
                <div class="row">
		
				<div class="col-md-12">
                <form id="masteruploadexcelfile">
				
				<!-- <section class="col-md-4">	
                    <label class="input">First Name <sup class="asterisk error">*</sup> </label>			
					<textarea name="m_first_name" class="form-control" id="m_first_name" ></textarea>			
				</section>
                <section class="col-md-4">	
                    <label class="input">Last Name <sup class="asterisk">*</sup> </label>			
					<input name="m_last_name" class="form-control" id="m_last_name" type="text">				
				</section> -->
                
                <footer>
                <input name="m_action" id="m_action" type="hidden">
                <button type="button"  class="btn btn-success btn-lg" onclick="getSaveData()">Save Data</button>	
                <button type="button"  class="btn btn-info btn-lg" onclick="Action(2)">Pull Films</button>
                <button type="button"  class="btn btn-primary btn-lg" onclick="Action(3)">Pull Peoples</button>	
                </footer>		           				
				<br>
				<section class="col-md-12">	
                    <label class="input"> Pull Data</label>			
					<textarea name="m_first_name" readonly style="border:solid 1px black;"class="form-control" id="m_first_name" ></textarea>			
				</section>
                <br>
                <table id= "save_data"  border="1" align="center" autosize="1.6" style="text-align:center;border-collapse: collapse; width:98%; margin-top:10px; ">
                
                
                </table>
                <br>
                <footer>
                
					
					
				
                <footer>
					
				</form>
			</div>
		
	            </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="loadMe" tabindex="-1" role="dialog" aria-labelledby="loadMeLabel" data-backdrop="static">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-body text-center">
        <div class="loader"></div>
        <div clas="loader-txt">
          <p>Please Wait...!</p>
        </div>
      </div>
    </div>
  </div>
</div>
<script src="{{URL::asset('assets/js/jquery-1.11.1.min.js')}}"></script>
<script>
$(document).ready(function () {
    getfilms_people();
});
var result;
function Action (id){   
    $("#loadMe").modal('show');
    $('#m_action').val(id);
    $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                url: "/action",
                type: "post",   
                dataType:"json",
                data:{'id':id} ,       
                success: function(response) {
                    //console.log(response);
                    $("#loadMe").modal('hide');
                    if(response.status == 200){
                        console.log(JSON.parse(response.message))
                        $('#m_first_name').val(JSON.parse(response.message))  
                    }else{
                        alert(response.message)
                    }
                                                                                                                 
                    
                },
                error: function(error) {
                   
                    $("#loadMe").modal('hide');
                    alert(error)
                    console.log(error);

                }
        });
   
}
function getSaveData(){
    if($('#m_first_name').val() != ""){
        $("#loadMe").modal('show');
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            url: "/getSaveData",
            type: "post", 
            dataType:'json' ,
            data:{'data':$('#m_first_name').val(),'m_action': $('#m_action').val()},         
            success: function(response) {
                console.log(response);
                $("#loadMe").modal('hide');                
                if(response.status == 200){
                    alert(response.message)
                    $('#m_first_name').val('');
                    getfilms_people();
                }else{
                    alert(response.message)
                }
                return false;
                var html='<tr>';
                html+= '<th>Sr.No.</th>';
                html+= '<th>First Name</th>';
                html+='<th>Last Name</th>';
                html+= '</tr>';
                
                if(response.status == 200){
                    if(response.message.length>0){
                            for(var i=0;i<response.message.length;i++){
                                // console.log(response.message[i].m_first_name)
                                // console.log(response.message[i].m_last_name)
                                html+='<tr>';
                                html+='<td>'+ parseInt(i+1) +'</td>';         
                                html+='<td>'+ response.message[i].m_first_name +'</td>';
                                html+='<td>'+ response.message[i].m_last_name +'</td>';                                                               
                                html+='<tr>';
                            }
                    }else{
                        html+='<tr>';
                        html+='<td>No records found</td>'; 
                        html+='<td>No records found</td>'; 
                        html+='<td>No records found</td>';                                
                        html+='<tr>';
                    }
                   
                }else{
                        html+='<tr>';
                        html+='<td>No records found</td>'; 
                        html+='<td>No records found</td>'; 
                        html+='<td>No records found</td>';                                
                        html+='<tr>';
                }
                $('#save_data').html(html);
            },
            error: function(error) {
                $("#loadMe").modal('hide');
                console.log(error);

            }
        });
    }else{
        alert('Please pull data first')
    }
    
}
function getfilms_people(){
  $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            url: "/getfilms_people",
            type: "get", 
            dataType:'json' ,                
            success: function(response) {
                console.log(response);                                                           
                var html='<tr>';
                html+= '<th>Sr.No.</th>';
                html+= '<th>Peoples</th>';
                html+='<th>Film Name</th>';
                html+= '</tr>';
                
                if(response.status == 200){
                    if(response.message.length>0){
                            for(var i=0;i<response.message.length;i++){
                                // console.log(response.message[i].m_first_name)
                                // console.log(response.message[i].m_last_name)
                                html+='<tr>';
                                html+='<td>'+ parseInt(i+1) +'</td>';         
                                html+='<td>'+ response.message[i].people +'</td>';
                                html+='<td>'+ response.message[i].film +'</td>';                                                               
                                html+='<tr>';
                            }
                    }else{
                        html+='<tr>';
                        html+='<td>No records found</td>'; 
                        html+='<td>No records found</td>'; 
                        html+='<td>No records found</td>';                                
                        html+='<tr>';
                    }
                   
                }else{
                        html+='<tr>';
                        html+='<td>No records found</td>'; 
                        html+='<td>No records found</td>'; 
                        html+='<td>No records found</td>';                                
                        html+='<tr>';
                }
                $('#save_data').html(html);
            },
            error: function(error) {
                $("#loadMe").modal('hide');
                console.log(error);

            }
        });
}
</script>
@endsection
