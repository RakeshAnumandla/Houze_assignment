<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SaveData extends Model
{
    protected $table = 'save_data';
	protected $primaryKey = 'Id';
	public $timestamps = false;

	protected $fillable = [
		'f_sys_cd_film', 'f_sys_cd_people'
	];


}
