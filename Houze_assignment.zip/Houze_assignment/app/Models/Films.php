<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Films extends Model
{
    protected $table = 'm_films';
	protected $primaryKey = 'Id';
	public $timestamps = false;

	protected $fillable = [
		'm_name'
	];

	public function peoples()
    {
        return $this->hasMany('App\Models\PeopleCharacter', 'f_sys_cd_film', 'Id');
    }
}
