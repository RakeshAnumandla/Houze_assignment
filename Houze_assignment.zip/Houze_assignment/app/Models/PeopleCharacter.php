<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PeopleCharacter extends Model
{
    protected $table = 'people_character';
	protected $primaryKey = 'Id';
	public $timestamps = false;

	protected $fillable = [
		'm_people', 'f_sys_cd_film'
	];

	public function films()
    {
        return $this->belongsTo('App\Models\Films', 'f_sys_cd_film', 'Id');
    }
}
