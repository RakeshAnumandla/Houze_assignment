<?php

namespace App\Http\Controllers;

use App\Models\Films;
use App\Models\PeopleCharacter;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use DB;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('home');
    }

    public function getSaveData(Request $request)
    {
        try {
            $data = json_decode($request->data, true);

            //return $data->['results'];
            $people_films = [];
            foreach ($data['results'] as $result) {
                if ($request->m_action == 2) { // films
                    $peoples = [];
                    foreach ($result['characters'] as $character) {
                        $characterdata = file_get_contents($character);
                        $characterdata = json_decode($characterdata, true);
                        $peoples[] = $characterdata['name'];
                    }

                    $people_films[] = array('film_name' => $result['title'], 'characters' => $peoples, 'm_action' => $request->m_action);
                } else {
                    $films = [];
                    foreach ($result['films'] as $character) {
                        $characterdata = file_get_contents($character);
                        $characterdata = json_decode($characterdata, true);
                        $films[] = $characterdata['title'];

                    }
                    $people_films[] = array('film_name' => $films, 'characters' => $result['name'], 'm_action' => $request->m_action);
                }

            }
            
            if (count($people_films) > 0) {
                DB::beginTransaction();
                foreach ($people_films as $people_film) {
                    if ($people_film['m_action'] == 2) { //films
                        $films = Films::where(['m_name' => $people_film['film_name']])->first();
                        if (empty($films)) {
                            $Film = new Films;
                            $Film->m_name = $people_film['film_name'];
                            $Film->save();
                            foreach ($people_film['characters'] as $character) {
                                $PeopleCharacters = PeopleCharacter::where(['f_sys_cd_film' => $Film->Id, 'm_people' => $character])->first();
                                if (empty($PeopleCharacters)) {
                                    $PeopleCharacter = new PeopleCharacter;
                                    $PeopleCharacter->m_people = $character;
                                    $Film->peoples()->save($PeopleCharacter);
                                }
                            }
                        }else{
                            foreach ($people_film['characters'] as $character) {
                                $PeopleCharacters = PeopleCharacter::where(['f_sys_cd_film' => $films->Id, 'm_people' => $character])->first();
                                if (empty($PeopleCharacters)) {
                                    $PeopleCharacter = new PeopleCharacter;
                                    $PeopleCharacter->m_people = $character;
                                    $PeopleCharacter->f_sys_cd_film = $films->Id;
                                    $PeopleCharacter->save();
                                }
                            } 
                        }
                    } else {
                      
                            foreach ($people_film['film_name'] as $film_name) {
                                $films = Films::where(['m_name' => $film_name])->first();
                                
                                if (empty($films)) {
                                    $Film = new Films;
                                    $Film->m_name = $film_name;
                                    $Film->save();
                                    $PeopleCharacter = new PeopleCharacter;
                                    $PeopleCharacter->m_people = $people_film['characters'];
                                    $Film->peoples()->save($PeopleCharacter);

                                }else{
                                $PeopleCharacters = PeopleCharacter::where(['f_sys_cd_film' => $films->Id, 'm_people' => $character])->first();
                                if (empty($PeopleCharacters)) {
                                    $PeopleCharacter = new PeopleCharacter;
                                    $PeopleCharacter->m_people = $character;
                                    $PeopleCharacter->f_sys_cd_film = $films->Id;
                                    $PeopleCharacter->save();
                                }
                                }
                            }
                        

                    }
                }

            }
            DB::commit();
            return response()->json([
                'status' => 200,
                'message' => "Successfully Saved Data",
            ]);
        } catch (\Exception $e) {
            if ($e->getMessage()) {
                DB::rollBack();
                return response()->json([
                    'status' => 500,
                    'message' => "Something went Wrong." . $e->getMessage(),
                ]);
            }
        }
    }

    public function Action(Request $request)
    {
        try {
            if ($request->id == 1) { // save dara

            } else if ($request->id == 2) { // pull films
                $result1 = file_get_contents('https://swapi.co/api/films');

            } else if ($request->id == 3) { // pull peoples
                $result1 = file_get_contents('https://swapi.co/api/people');

            }
            return response()->json([
                'status' => 200,
                'message' => json_encode($result1),
            ]);
        } catch (\Exception $e) {
            if ($e->getMessage()) {
                return response()->json([
                    'status' => 500,
                    'message' => "Something went Wrong." . $e->getMessage(),
                ]);
            }
        }
    }

    public function getfilms_people()
    {
        try {
            $PeopleCharacters = PeopleCharacter::with('films')->get();
            $data = [];
            if (count($PeopleCharacters) > 0) {
                foreach ($PeopleCharacters as $PeopleCharacter) {
                    $data[] = array('people' => $PeopleCharacter->m_people, 'film' => $PeopleCharacter->films->m_name);
                }
            }
            return response()->json([
                'status' => 200,
                'message' => $data,
            ]);
        } catch (\Exception $e) {
            if ($e->getMessage()) {
                return response()->json([
                    'status' => 500,
                    'message' => "Something went Wrong." . $e->getMessage(),
                ]);
            }
        }
        //return view('master',['data'=>$data,'id'=>$id]);
    }


    public function getpage2()
    {
        try {
             $result1 = file_get_contents('https://swapi.co/api/films');
             $Films = [];
             $PeopleCharacters = [];
             $result1 = json_decode($result1,true);
             
             foreach($result1['results'] as $value){
                $Films[] = $value['title'];
             }
            $result2 = file_get_contents('https://swapi.co/api/people');
            $result2 = json_decode($result2,true);
            foreach($result2['results'] as $value){
               
                $PeopleCharacters[] = $value['name'];
             }
                                   
            return view('master',['PeopleCharacters'=>$PeopleCharacters,'Films'=>$Films]);
            
        } catch (\Exception $e) {
            if ($e->getMessage()) {
                return response()->json([
                    'status' => 500,
                    'message' => "Something went Wrong." . $e->getMessage(),
                ]);
            }
        }
        
    }

    public function getpeoplefilms(Request $request)
    {
        try {
            $response = [];
            if($request->id==2){
                $PeopleCharacters = PeopleCharacter::where('m_people',$request->name)->with('films')->get();
                if(count($PeopleCharacters)>0){
                    foreach($PeopleCharacters as $PeopleCharacter){
                        $response[] = $PeopleCharacter->films->m_name;

                    }
                }
            }else{
                
                $Films = Films::where('m_name',$request->name)->with('peoples')->first();
                if(!empty($Films)){
                    foreach($Films->peoples as $PeopleCharacter){
                        $response[] = $PeopleCharacter->m_people;

                    }
                }
            }
            
            
            return response()->json([
                'status' => 200,
                'message' =>$response,
            ]);
            
        } catch (\Exception $e) {
            if ($e->getMessage()) {
                return response()->json([
                    'status' => 500,
                    'message' => "Something went Wrong." . $e->getMessage(),
                ]);
            }
        }
        
    }
}
